# پلاسکو اسکندری — بسته نهایی سورس نسخه ۳

این بسته شامل سورس Flutter، تنظیمات اتصال Android به Firebase، قواعد Firestore و Storage و تابع امن ثبت سفارش است. این فایل APK نیست.

## تنظیمات پروژه
- Firebase project: `plasco-eskandari-new-f2bb4`
- Android package: `com.plasco.app`
- Firestore region: `eur3` (طبق تنظیمی که در کنسول انجام شده)
- Cloud Function region: `us-central1`

## راه‌اندازی اولیه Firebase
1. در Authentication روش Email/Password فعال باشد.
2. در Firestore سند `users/664bhYJJpET3nSWqzi5dVcA1yOl1` را با فیلدهای `name` (String) و `role` (String=`manager`) ایجاد کنید؛ این UID مربوط به حساب مدیر معرفی‌شده است.
3. قواعد `firebase/firestore.rules` را در Firestore Rules منتشر کنید.
4. قواعد `firebase/storage.rules` را در Storage Rules منتشر کنید.
5. تابع `createSalesOrder` از پوشه `functions` باید با Firebase CLI مستقر شود؛ ثبت سفارش در قواعد Firestore عمداً مستقیم مسدود است و فقط تابع سرور مجاز به ساخت سفارش است.

## استقرار تابع امن
در محیطی که Node.js 20 و Firebase CLI نصب است، از ریشه این پروژه اجرا کنید:
```bash
cd functions
npm install
npm run build
cd ..
firebase deploy --only functions:createSalesOrder
```
اگر CLI درخواست انتخاب پروژه کرد، پروژه `plasco-eskandari-new-f2bb4` را انتخاب کنید.

## ساخت APK با GitHub Actions
محتویات این ZIP را در ریشه مخزن GitHub قرار دهید؛ پوشه‌های `lib`، `functions` و `firebase` و فایل `pubspec.yaml` باید در ریشه باشند. سپس workflow ساخت Android را اجرا کنید.

## نکته مهم امنیتی
- سفارش‌ها فقط از طریق تابع سرور `createSalesOrder` ساخته می‌شوند. تابع نقش کاربر را بررسی می‌کند، قیمت اختصاصی همان مشتری را از Firestore می‌خواند و مبلغ را سمت سرور محاسبه می‌کند.
- فروشنده فقط سفارش‌های خودش را می‌خواند؛ مدیر همه سفارش‌ها را می‌خواند.
- قیمت واحد و جمع هر ردیف داخل سفارش ذخیره می‌شود تا تغییر قیمت بعدی، سفارش‌های قبلی را تغییر ندهد.
- وجود قواعد و تابع در ZIP به معنی استقرار آن‌ها در Firebase نیست؛ مراحل بالا باید انجام و سپس با حساب مدیر و فروشنده آزمایش شوند.
- قبل از استفاده عملیاتی، با داده آزمایشی و Firebase Emulator Suite تست کنید.

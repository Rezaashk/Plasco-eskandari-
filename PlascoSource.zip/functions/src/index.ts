import { onCall, HttpsError } from 'firebase-functions/v2/https';
import { initializeApp } from 'firebase-admin/app';
import { getFirestore, FieldValue } from 'firebase-admin/firestore';

initializeApp();
const db = getFirestore();

export const createSalesOrder = onCall({ region: 'us-central1', enforceAppCheck: false }, async (request) => {
  if (!request.auth) throw new HttpsError('unauthenticated', 'ابتدا وارد حساب شوید.');
  const uid = request.auth.uid;
  const profile = await db.collection('users').doc(uid).get();
  const role = profile.get('role');
  if (!profile.exists || !['manager', 'sales'].includes(role)) {
    throw new HttpsError('permission-denied', 'حساب کاربری مجاز نیست.');
  }
  const customerId = request.data?.customerId;
  const rawItems = request.data?.items;
  const paymentMethod = request.data?.paymentMethod;
  if (typeof customerId !== 'string' || !customerId || !Array.isArray(rawItems) || rawItems.length < 1 || rawItems.length > 50) {
    throw new HttpsError('invalid-argument', 'مشتری و اقلام سفارش معتبر نیستند.');
  }
  if (!['نقدی', 'کارت‌به‌کارت', 'اعتباری'].includes(paymentMethod)) {
    throw new HttpsError('invalid-argument', 'روش پرداخت معتبر نیست.');
  }
  const customerRef = db.collection('customers').doc(customerId);
  const customer = await customerRef.get();
  if (!customer.exists) throw new HttpsError('not-found', 'مشتری پیدا نشد.');
  const normalized: Array<Record<string, unknown>> = [];
  let total = 0;
  const seen = new Set<string>();
  for (const item of rawItems) {
    const productId = item?.productId;
    const quantity = item?.quantity;
    if (typeof productId !== 'string' || !productId || seen.has(productId) || !Number.isSafeInteger(quantity) || quantity <= 0 || quantity > 1000000) {
      throw new HttpsError('invalid-argument', 'کالا یا تعداد آن معتبر نیست.');
    }
    seen.add(productId);
    const [product, priceDoc] = await Promise.all([
      db.collection('products').doc(productId).get(),
      customerRef.collection('prices').doc(productId).get(),
    ]);
    if (!product.exists) throw new HttpsError('not-found', 'یکی از کالاها پیدا نشد.');
    if (!priceDoc.exists || !Number.isSafeInteger(priceDoc.get('price')) || priceDoc.get('price') < 0) {
      throw new HttpsError('failed-precondition', `قیمت اختصاصی کالا ${product.get('name') ?? ''} ثبت نشده یا نامعتبر است.`);
    }
    const unitPrice = priceDoc.get('price') as number;
    const lineTotal = unitPrice * quantity;
    if (!Number.isSafeInteger(lineTotal) || !Number.isSafeInteger(total + lineTotal)) {
      throw new HttpsError('out-of-range', 'مبلغ سفارش بیش از حد مجاز است.');
    }
    total += lineTotal;
    normalized.push({ productId, name: product.get('name') ?? '', code: product.get('code') ?? '', quantity, unitPrice, lineTotal });
  }
  const order = await db.collection('orders').add({
    customerId, customerName: customer.get('name') ?? '', items: normalized, total,
    paymentMethod, status: 'ثبت‌شده', salespersonUid: uid,
    createdAt: FieldValue.serverTimestamp(),
  });
  return { orderId: order.id, total };
});

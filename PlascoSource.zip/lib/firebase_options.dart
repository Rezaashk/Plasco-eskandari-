import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/foundation.dart';

/// Firebase configuration for the Android app registered in this project.
/// Values correspond to the google-services.json used by the GitHub build.
class DefaultFirebaseOptions {
  static FirebaseOptions get currentPlatform {
    if (kIsWeb) {
      throw UnsupportedError('این نسخه فقط برای Android پیکربندی شده است.');
    }
    return android;
  }

  static const FirebaseOptions android = FirebaseOptions(
    apiKey: 'AIzaSyAQAqC1MwJaeMIfIG5QCvd9JWcrJTmCE',
    appId: '1:916809780587:android:a08d21881916eba61e902e',
    messagingSenderId: '916809780587',
    projectId: 'plasco-eskandari-new-f2bb4',
    storageBucket: 'plasco-eskandari-new-f2bb4.firebasestorage.app',
  );
}

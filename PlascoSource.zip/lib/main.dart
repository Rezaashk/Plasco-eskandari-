import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:cloud_functions/cloud_functions.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_core/firebase_core.dart';
import 'firebase_options.dart';
import 'package:firebase_storage/firebase_storage.dart';
import 'package:flutter/material.dart';
import 'dart:ui' as ui;
import 'package:image_picker/image_picker.dart';
import 'dart:io';
import 'package:intl/intl.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  try {
    await Firebase.initializeApp(
      options: DefaultFirebaseOptions.currentPlatform,
    );
    runApp(const PlascoApp());
  } catch (e) {
    runApp(FirebaseStartupError(error: e.toString()));
  }
}


class FirebaseStartupError extends StatelessWidget {
  final String error;
  const FirebaseStartupError({super.key, required this.error});

  @override
  Widget build(BuildContext context) => MaterialApp(
        debugShowCheckedModeBanner: false,
        home: Directionality(
          textDirection: ui.TextDirection.rtl,
          child: Scaffold(
            body: SafeArea(
              child: Center(
                child: Padding(
                  padding: const EdgeInsets.all(24),
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      const Icon(Icons.cloud_off_outlined, size: 56, color: Colors.red),
                      const SizedBox(height: 16),
                      const Text('راه‌اندازی Firebase ناموفق بود',
                          style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
                      const SizedBox(height: 12),
                      const Text('برنامه نتوانست به تنظیمات Firebase متصل شود.'),
                      const SizedBox(height: 12),
                      SelectableText(error, textAlign: TextAlign.center),
                    ],
                  ),
                ),
              ),
            ),
          ),
        ),
      );
}

final money = NumberFormat('#,##0', 'en_US');

class PlascoApp extends StatelessWidget {
  const PlascoApp({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
        title: 'پلاسکو اسکندری',
        debugShowCheckedModeBanner: false,
        theme: ThemeData(
          colorScheme: ColorScheme.fromSeed(seedColor: const Color(0xff174a7e)),
          useMaterial3: true,
          fontFamily: 'Roboto',
        ),
        home: const Directionality(textDirection: ui.TextDirection.rtl, child: AuthGate()),
      );
}

class AuthGate extends StatelessWidget {
  const AuthGate({super.key});
  @override
  Widget build(BuildContext context) => StreamBuilder<User?>(
        stream: FirebaseAuth.instance.authStateChanges(),
        builder: (context, snap) {
          if (snap.connectionState == ConnectionState.waiting) {
            return const Scaffold(body: Center(child: CircularProgressIndicator()));
          }
          if (snap.data == null) return const LoginPage();
          return const HomePage();
        },
      );
}

class LoginPage extends StatefulWidget {
  const LoginPage({super.key});
  @override
  State<LoginPage> createState() => _LoginPageState();
}

class _LoginPageState extends State<LoginPage> {
  final email = TextEditingController();
  final password = TextEditingController();
  bool busy = false;
  String? error;

  Future<void> login() async {
    setState(() { busy = true; error = null; });
    try {
      await FirebaseAuth.instance.signInWithEmailAndPassword(
        email: email.text.trim(), password: password.text,
      );
    } on FirebaseAuthException catch (e) {
      setState(() => error = 'کد خطا: ${e.code}\n${e.message ?? 'ورود انجام نشد.'}');
    } catch (_) {
      setState(() => error = 'اتصال برقرار نشد. تنظیمات Firebase را بررسی کنید.');
    } finally {
      if (mounted) setState(() => busy = false);
    }
  }

  @override
  Widget build(BuildContext context) => Scaffold(
        body: SafeArea(
          child: Center(
            child: SingleChildScrollView(
              padding: const EdgeInsets.all(24),
              child: ConstrainedBox(
                constraints: const BoxConstraints(maxWidth: 420),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    const Icon(Icons.factory_outlined, size: 64, color: Color(0xff174a7e)),
                    const SizedBox(height: 12),
                    const Text('پلاسکو اسکندری', textAlign: TextAlign.center,
                        style: TextStyle(fontSize: 26, fontWeight: FontWeight.bold)),
                    const SizedBox(height: 6),
                    const Text('ورود مدیر یا فروشنده', textAlign: TextAlign.center),
                    const SizedBox(height: 28),
                    TextField(controller: email, keyboardType: TextInputType.emailAddress,
                      decoration: const InputDecoration(labelText: 'ایمیل کاربری', border: OutlineInputBorder())),
                    const SizedBox(height: 12),
                    TextField(controller: password, obscureText: true,
                      decoration: const InputDecoration(labelText: 'رمز عبور', border: OutlineInputBorder())),
                    if (error != null) Padding(padding: const EdgeInsets.only(top: 12),
                      child: Text(error!, style: const TextStyle(color: Colors.red))),
                    const SizedBox(height: 18),
                    FilledButton(onPressed: busy ? null : login,
                      child: Text(busy ? 'در حال ورود...' : 'ورود')),
                    const SizedBox(height: 12),
                    const Text('حساب‌ها باید توسط مدیر در Firebase ایجاد شوند.',
                        textAlign: TextAlign.center, style: TextStyle(fontSize: 12)),
                  ],
                ),
              ),
            ),
          ),
        ),
      );
}

class HomePage extends StatefulWidget {
  const HomePage({super.key});
  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  int index = 0;
  String? role;
  String displayName = 'کاربر';
  String? profileError;
  bool profileLoading = true;

  @override
  void initState() { super.initState(); loadProfile(); }

  Future<void> loadProfile() async {
    final uid = FirebaseAuth.instance.currentUser!.uid;
    try {
      final doc = await FirebaseFirestore.instance.collection('users').doc(uid).get();
      if (!mounted) return;
      final data = doc.data();
      final loadedRole = (data?['role'] ?? '').toString();
      if (!doc.exists || !['manager', 'sales'].contains(loadedRole)) {
        setState(() {
          role = null;
          profileError = 'برای این حساب نقش معتبر در سامانه تعریف نشده است. با مدیر سامانه تماس بگیرید.';
          profileLoading = false;
        });
        return;
      }
      setState(() {
        role = loadedRole;
        displayName = (data?['name'] ?? FirebaseAuth.instance.currentUser?.email ?? 'کاربر').toString();
        profileError = null;
        profileLoading = false;
      });
    } catch (e) {
      if (!mounted) return;
      setState(() {
        role = null;
        profileError = 'خواندن مشخصات حساب ناموفق بود. اتصال اینترنت و قوانین دسترسی Firebase را بررسی کنید.';
        profileLoading = false;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    if (profileLoading) {
      return const Scaffold(body: Center(child: CircularProgressIndicator()));
    }
    if (role == null) {
      return Scaffold(
        appBar: AppBar(title: const Text('پلاسکو اسکندری'), actions: [
          IconButton(tooltip: 'خروج', onPressed: () => FirebaseAuth.instance.signOut(), icon: const Icon(Icons.logout)),
        ]),
        body: Center(child: Padding(padding: const EdgeInsets.all(24), child: Column(
          mainAxisSize: MainAxisSize.min, children: [
            const Icon(Icons.account_circle_outlined, size: 56),
            const SizedBox(height: 16),
            Text(profileError ?? 'مشخصات حساب در دسترس نیست.', textAlign: TextAlign.center),
            const SizedBox(height: 16),
            OutlinedButton.icon(onPressed: () { setState(() { profileLoading = true; profileError = null; }); loadProfile(); }, icon: const Icon(Icons.refresh), label: const Text('تلاش دوباره')),
          ],
        ))),
      );
    }
    final pages = <Widget>[
      DashboardPage(role: role!, name: displayName),
      ProductsPage(isManager: role == 'manager'),
      CustomersPage(isManager: role == 'manager'),
      PricesPage(isManager: role == 'manager'),
      OrdersPage(isManager: role == 'manager', salespersonUid: FirebaseAuth.instance.currentUser!.uid),
    ];
    final labels = ['خانه', 'محصولات', 'مشتریان', 'قیمت‌ها', 'سفارش‌ها'];
    final icons = [Icons.home_outlined, Icons.inventory_2_outlined, Icons.people_outline, Icons.price_change_outlined, Icons.receipt_long_outlined];
    return Scaffold(
      appBar: AppBar(title: const Text('پلاسکو اسکندری'), actions: [
        IconButton(tooltip: 'خروج', onPressed: () => FirebaseAuth.instance.signOut(), icon: const Icon(Icons.logout)),
      ]),
      body: pages[index],
      bottomNavigationBar: NavigationBar(
        selectedIndex: index,
        onDestinationSelected: (v) => setState(() => index = v),
        destinations: List.generate(labels.length, (i) => NavigationDestination(icon: Icon(icons[i]), label: labels[i])),
      ),
    );
  }
}

class DashboardPage extends StatelessWidget {
  final String role, name;
  const DashboardPage({super.key, required this.role, required this.name});
  @override
  Widget build(BuildContext context) => ListView(
    padding: const EdgeInsets.all(16),
    children: [
      Card(child: Padding(padding: const EdgeInsets.all(18), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text('سلام $name', style: const TextStyle(fontSize: 21, fontWeight: FontWeight.bold)),
        const SizedBox(height: 6),
        Text(role == 'manager' ? 'دسترسی مدیر' : 'دسترسی فروشنده'),
        const SizedBox(height: 6),
        const Text('اطلاعات این برنامه از پایگاه داده آنلاین خوانده می‌شود.'),
      ]))),
      const SizedBox(height: 12),
      const _StatCard(title: 'محصولات', collection: 'products', icon: Icons.inventory_2_outlined),
      const _StatCard(title: 'مشتریان', collection: 'customers', icon: Icons.people_outline),
      const _StatCard(title: 'سفارش‌ها', collection: 'orders', icon: Icons.receipt_long_outlined),
    ],
  );
}

class _StatCard extends StatelessWidget {
  final String title, collection;
  final IconData icon;
  const _StatCard({required this.title, required this.collection, required this.icon});
  @override
  Widget build(BuildContext context) => Card(child: ListTile(
    leading: Icon(icon), title: Text(title),
    trailing: StreamBuilder<QuerySnapshot<Map<String, dynamic>>>(
      stream: FirebaseFirestore.instance.collection(collection).snapshots(),
      builder: (context, snap) => Text('${snap.data?.docs.length ?? 0}'),
    ),
  ));
}

class ProductsPage extends StatelessWidget {
  final bool isManager;
  const ProductsPage({super.key, required this.isManager});
  @override
  Widget build(BuildContext context) => Scaffold(
    body: StreamBuilder<QuerySnapshot<Map<String, dynamic>>>(
      stream: FirebaseFirestore.instance.collection('products').orderBy('name').snapshots(),
      builder: (context, snap) {
        if (snap.hasError) return const Center(child: Text('خطا در خواندن محصولات؛ قوانین Firebase را بررسی کنید.'));
        if (!snap.hasData) return const Center(child: CircularProgressIndicator());
        final docs = snap.data!.docs;
        if (docs.isEmpty) return const Center(child: Text('هنوز محصولی ثبت نشده است.'));
        return ListView(children: docs.map((d) {
          final x = d.data();
          return ListTile(
            leading: x['imageUrl'] == null ? const Icon(Icons.inventory_2_outlined) : CircleAvatar(backgroundImage: NetworkImage(x['imageUrl'])),
            title: Text('${x['name'] ?? ''}'),
            subtitle: Text('کد: ${x['code'] ?? '-'} · ${x['volume'] ?? ''} · ${x['color'] ?? ''}'),
          );
        }).toList());
      },
    ),
    floatingActionButton: isManager ? FloatingActionButton.extended(
      onPressed: () => showDialog(context: context, builder: (_) => const ProductDialog()),
      icon: const Icon(Icons.add), label: const Text('محصول جدید'),
    ) : null,
  );
}

class ProductDialog extends StatefulWidget {
  const ProductDialog({super.key});
  @override
  State<ProductDialog> createState() => _ProductDialogState();
}
class _ProductDialogState extends State<ProductDialog> {
  final name = TextEditingController(), code = TextEditingController(), volume = TextEditingController(), color = TextEditingController(), weight = TextEditingController(), basePrice = TextEditingController();
  XFile? photo;
  bool busy = false;
  String? error;

  Future<void> save() async {
    if (name.text.trim().isEmpty || code.text.trim().isEmpty) { setState(() => error = 'نام و کد محصول ضروری است.'); return; }
    setState(() { busy = true; error = null; });
    try {
      String? url;
      if (photo != null) {
        final ref = FirebaseStorage.instance.ref('products/${DateTime.now().millisecondsSinceEpoch}_${photo!.name}');
        await ref.putFile(File(photo!.path));
        url = await ref.getDownloadURL();
      }
      await FirebaseFirestore.instance.collection('products').add({
        'name': name.text.trim(), 'code': code.text.trim(), 'volume': volume.text.trim(),
        'color': color.text.trim(), 'weight': weight.text.trim(),
        'basePrice': int.tryParse(basePrice.text) ?? 0, 'imageUrl': url,
        'createdAt': FieldValue.serverTimestamp(),
      });
      if (mounted) Navigator.pop(context);
    } catch (_) { setState(() => error = 'ذخیره نشد؛ اتصال یا مجوزهای Firebase را بررسی کنید.'); }
    finally { if (mounted) setState(() => busy = false); }
  }

  @override
  Widget build(BuildContext context) => AlertDialog(
    title: const Text('ثبت محصول'),
    content: SingleChildScrollView(child: Column(mainAxisSize: MainAxisSize.min, children: [
      _field(name, 'نام محصول *'), _field(code, 'کد محصول *'), _field(volume, 'حجم'),
      _field(color, 'رنگ'), _field(weight, 'وزن (اختیاری)'), _field(basePrice, 'قیمت پایه (تومان)', numeric: true),
      OutlinedButton.icon(onPressed: () async { final x = await ImagePicker().pickImage(source: ImageSource.gallery, imageQuality: 80); if (x != null) setState(() => photo = x); },
        icon: const Icon(Icons.photo_library_outlined), label: Text(photo?.name ?? 'انتخاب عکس از گالری')),
      if (error != null) Text(error!, style: const TextStyle(color: Colors.red)),
    ])),
    actions: [TextButton(onPressed: busy ? null : () => Navigator.pop(context), child: const Text('لغو')),
      FilledButton(onPressed: busy ? null : save, child: Text(busy ? 'در حال ذخیره...' : 'ذخیره'))],
  );
}

Widget _field(TextEditingController c, String label, {bool numeric = false}) => Padding(
  padding: const EdgeInsets.only(bottom: 10),
  child: TextField(controller: c, keyboardType: numeric ? TextInputType.number : TextInputType.text,
    decoration: InputDecoration(labelText: label, border: const OutlineInputBorder(), isDense: true)),
);

class CustomersPage extends StatelessWidget {
  final bool isManager;
  const CustomersPage({super.key, required this.isManager});
  @override
  Widget build(BuildContext context) => Scaffold(
    body: StreamBuilder<QuerySnapshot<Map<String, dynamic>>>(
      stream: FirebaseFirestore.instance.collection('customers').orderBy('name').snapshots(),
      builder: (context, snap) {
        if (snap.hasError) return const Center(child: Text('خطا در خواندن مشتریان.'));
        if (!snap.hasData) return const Center(child: CircularProgressIndicator());
        if (snap.data!.docs.isEmpty) return const Center(child: Text('هنوز مشتری ثبت نشده است.'));
        return ListView(children: snap.data!.docs.map((d) {
          final x = d.data();
          return ListTile(leading: const CircleAvatar(child: Icon(Icons.person_outline)),
            title: Text('${x['name'] ?? ''}'), subtitle: Text('${x['phone'] ?? ''} · ${x['city'] ?? ''}'));
        }).toList());
      },
    ),
    floatingActionButton: isManager ? FloatingActionButton.extended(
      onPressed: () => showDialog(context: context, builder: (_) => const CustomerDialog()),
      icon: const Icon(Icons.person_add_alt_1), label: const Text('مشتری جدید'),
    ) : null,
  );
}

class CustomerDialog extends StatefulWidget {
  const CustomerDialog({super.key});
  @override
  State<CustomerDialog> createState() => _CustomerDialogState();
}
class _CustomerDialogState extends State<CustomerDialog> {
  final name = TextEditingController(), phone = TextEditingController(), city = TextEditingController(), notes = TextEditingController();
  String kind = 'عمده‌فروش';
  String? error;
  bool busy = false;
  Future<void> save() async {
    if (name.text.trim().isEmpty || phone.text.trim().isEmpty) { setState(() => error = 'نام و شماره تماس ضروری است.'); return; }
    setState(() { busy = true; error = null; });
    try {
      await FirebaseFirestore.instance.collection('customers').add({
        'name': name.text.trim(), 'phone': phone.text.trim(), 'city': city.text.trim(),
        'type': kind, 'notes': notes.text.trim(), 'createdAt': FieldValue.serverTimestamp(),
      });
      if (mounted) Navigator.pop(context);
    } catch (_) { setState(() => error = 'ذخیره مشتری انجام نشد.'); }
    finally { if (mounted) setState(() => busy = false); }
  }
  @override
  Widget build(BuildContext context) => AlertDialog(
    title: const Text('ثبت مشتری'),
    content: SingleChildScrollView(child: Column(mainAxisSize: MainAxisSize.min, children: [
      _field(name, 'نام مشتری یا شرکت *'), _field(phone, 'شماره تماس *'), _field(city, 'شهر'),
      DropdownButtonFormField<String>(value: kind, decoration: const InputDecoration(labelText: 'نوع مشتری'),
        items: ['عمده‌فروش','توزیع‌کننده','فروشگاه','سایر'].map((v) => DropdownMenuItem(value: v, child: Text(v))).toList(),
        onChanged: (v) => setState(() => kind = v ?? 'سایر')),
      _field(notes, 'توضیحات'),
      if (error != null) Text(error!, style: const TextStyle(color: Colors.red)),
    ])),
    actions: [TextButton(onPressed: busy ? null : () => Navigator.pop(context), child: const Text('لغو')),
      FilledButton(onPressed: busy ? null : save, child: Text(busy ? 'در حال ذخیره...' : 'ذخیره'))],
  );
}

class PricesPage extends StatelessWidget {
  final bool isManager;
  const PricesPage({super.key, required this.isManager});
  @override
  Widget build(BuildContext context) {
    if (!isManager) return const Center(child: Padding(padding: EdgeInsets.all(24),
      child: Text('فروشنده اجازه تغییر قیمت را ندارد. برای ثبت سفارش، قیمت‌های تأییدشده را مشاهده می‌کند.')));
    return Scaffold(
      body: StreamBuilder<QuerySnapshot<Map<String, dynamic>>>(
        stream: FirebaseFirestore.instance.collection('customers').orderBy('name').snapshots(),
        builder: (context, snap) {
          if (!snap.hasData) return const Center(child: CircularProgressIndicator());
          if (snap.data!.docs.isEmpty) return const Center(child: Text('ابتدا مشتری ثبت کنید.'));
          return ListView(children: snap.data!.docs.map((d) => ListTile(
            leading: const Icon(Icons.sell_outlined), title: Text('${d.data()['name'] ?? ''}'),
            subtitle: const Text('برای تنظیم قیمت، مشتری را باز کنید'),
            onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => CustomerPricesPage(customerId: d.id, customerName: '${d.data()['name'] ?? ''}'))),
          )).toList());
        },
      ),
    );
  }
}

class CustomerPricesPage extends StatelessWidget {
  final String customerId, customerName;
  const CustomerPricesPage({super.key, required this.customerId, required this.customerName});
  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: Text('قیمت‌های $customerName')),
    body: StreamBuilder<QuerySnapshot<Map<String, dynamic>>>(
      stream: FirebaseFirestore.instance.collection('products').orderBy('name').snapshots(),
      builder: (context, snap) {
        if (!snap.hasData) return const Center(child: CircularProgressIndicator());
        return ListView(children: snap.data!.docs.map((p) => ListTile(
          title: Text('${p.data()['name'] ?? ''}'),
          subtitle: Text('کد ${p.data()['code'] ?? ''}'),
          trailing: IconButton(icon: const Icon(Icons.edit_outlined), onPressed: () => showDialog(
            context: context, builder: (_) => PriceDialog(customerId: customerId, productId: p.id, productName: '${p.data()['name'] ?? ''}'))),
        )).toList());
      },
    ),
  );
}

class PriceDialog extends StatefulWidget {
  final String customerId, productId, productName;
  const PriceDialog({super.key, required this.customerId, required this.productId, required this.productName});
  @override
  State<PriceDialog> createState() => _PriceDialogState();
}
class _PriceDialogState extends State<PriceDialog> {
  final price = TextEditingController();
  bool busy = false;
  String? error;
  @override
  void initState() { super.initState(); load(); }
  Future<void> load() async {
    final d = await FirebaseFirestore.instance.collection('customers').doc(widget.customerId).collection('prices').doc(widget.productId).get();
    if (mounted && d.exists) price.text = '${d.data()?['price'] ?? ''}';
  }
  Future<void> save() async {
    final v = int.tryParse(price.text);
    if (v == null || v < 0) { setState(() => error = 'قیمت معتبر وارد کنید.'); return; }
    setState(() => busy = true);
    try {
      await FirebaseFirestore.instance.collection('customers').doc(widget.customerId).collection('prices').doc(widget.productId).set({
        'price': v, 'updatedAt': FieldValue.serverTimestamp(), 'updatedBy': FirebaseAuth.instance.currentUser!.uid,
      });
      if (mounted) Navigator.pop(context);
    } catch (_) { setState(() => error = 'ذخیره قیمت انجام نشد؛ دسترسی مدیر را بررسی کنید.'); }
    finally { if (mounted) setState(() => busy = false); }
  }
  @override
  Widget build(BuildContext context) => AlertDialog(
    title: Text(widget.productName),
    content: Column(mainAxisSize: MainAxisSize.min, children: [
      _field(price, 'قیمت اختصاصی هر عدد (تومان)', numeric: true),
      if (error != null) Text(error!, style: const TextStyle(color: Colors.red)),
    ]),
    actions: [TextButton(onPressed: () => Navigator.pop(context), child: const Text('لغو')),
      FilledButton(onPressed: busy ? null : save, child: const Text('ذخیره قیمت'))],
  );
}

class OrdersPage extends StatelessWidget {
  final bool isManager;
  final String salespersonUid;
  const OrdersPage({super.key, required this.isManager, required this.salespersonUid});
  @override
  Widget build(BuildContext context) => Scaffold(
    body: StreamBuilder<QuerySnapshot<Map<String, dynamic>>>(
      stream: (isManager
          ? FirebaseFirestore.instance.collection('orders')
          : FirebaseFirestore.instance.collection('orders').where('salespersonUid', isEqualTo: salespersonUid))
          .orderBy('createdAt', descending: true).snapshots(),
      builder: (context, snap) {
        if (snap.hasError) return const Center(child: Text('خطا در خواندن سفارش‌ها.'));
        if (!snap.hasData) return const Center(child: CircularProgressIndicator());
        if (snap.data!.docs.isEmpty) return const Center(child: Text('هنوز سفارشی ثبت نشده است.'));
        return ListView(children: snap.data!.docs.map((d) {
          final x = d.data();
          return ListTile(
            leading: const Icon(Icons.receipt_long_outlined),
            title: Text('${x['customerName'] ?? 'مشتری'} · ${money.format(x['total'] ?? 0)} تومان'),
            subtitle: Text('وضعیت: ${x['status'] ?? 'ثبت‌شده'}'),
          );
        }).toList());
      },
    ),
    floatingActionButton: FloatingActionButton.extended(
      onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const NewOrderPage())),
      icon: const Icon(Icons.add_shopping_cart), label: const Text('سفارش جدید'),
    ),
  );
}

class NewOrderPage extends StatefulWidget {
  const NewOrderPage({super.key});
  @override
  State<NewOrderPage> createState() => _NewOrderPageState();
}
class _NewOrderPageState extends State<NewOrderPage> {
  String? customerId;
  Map<String, int> quantities = {};
  Map<String, Map<String, dynamic>> selectedProducts = {};
  String payment = 'نقدی';
  bool busy = false;
  String? error;

  Future<void> submit(List<QueryDocumentSnapshot<Map<String, dynamic>>> customers) async {
    if (customerId == null || quantities.values.every((q) => q == 0)) {
      setState(() => error = 'مشتری و حداقل یک محصول را انتخاب کنید.'); return;
    }
    setState(() { busy = true; error = null; });
    try {
      final payload = <String, dynamic>{
        'customerId': customerId,
        'paymentMethod': payment,
        'items': quantities.entries.where((e) => e.value > 0)
            .map((e) => {'productId': e.key, 'quantity': e.value}).toList(),
      };
      await FirebaseFunctions.instance.httpsCallable('createSalesOrder').call(payload);
      if (mounted) Navigator.pop(context);
    } catch (e) { setState(() => error = e.toString().replaceFirst('Exception: ', '')); }
    finally { if (mounted) setState(() => busy = false); }
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('ثبت سفارش جدید')),
    body: StreamBuilder<QuerySnapshot<Map<String, dynamic>>>(
      stream: FirebaseFirestore.instance.collection('customers').orderBy('name').snapshots(),
      builder: (context, cs) {
        if (!cs.hasData) return const Center(child: CircularProgressIndicator());
        final customers = cs.data!.docs;
        return StreamBuilder<QuerySnapshot<Map<String, dynamic>>>(
          stream: FirebaseFirestore.instance.collection('products').orderBy('name').snapshots(),
          builder: (context, ps) {
            if (!ps.hasData) return const Center(child: CircularProgressIndicator());
            selectedProducts = {for (final p in ps.data!.docs) p.id: p.data()};
            int displayedTotal = 0;
            return ListView(padding: const EdgeInsets.all(16), children: [
              DropdownButtonFormField<String>(
                value: customerId, decoration: const InputDecoration(labelText: 'انتخاب مشتری', border: OutlineInputBorder()),
                items: customers.map((c) => DropdownMenuItem(value: c.id, child: Text('${c.data()['name'] ?? ''}'))).toList(),
                onChanged: (v) => setState(() => customerId = v),
              ),
              const SizedBox(height: 12),
              ...ps.data!.docs.map((p) {
                final q = quantities[p.id] ?? 0;
                return Card(child: ListTile(
                  title: Text('${p.data()['name'] ?? ''}'),
                  subtitle: Text('کد: ${p.data()['code'] ?? '-'} · قیمت با انتخاب مشتری بررسی می‌شود'),
                  trailing: SizedBox(width: 140, child: Row(children: [
                    IconButton(onPressed: () => setState(() => quantities[p.id] = (q - 1).clamp(0, 999999).toInt()), icon: const Icon(Icons.remove_circle_outline)),
                    Text('$q'),
                    IconButton(onPressed: () => setState(() => quantities[p.id] = q + 1), icon: const Icon(Icons.add_circle_outline)),
                  ])),
                ));
              }),
              const SizedBox(height: 12),
              DropdownButtonFormField<String>(value: payment, decoration: const InputDecoration(labelText: 'روش پرداخت', border: OutlineInputBorder()),
                items: ['نقدی','کارت‌به‌کارت','اعتباری'].map((v) => DropdownMenuItem(value: v, child: Text(v))).toList(),
                onChanged: (v) => setState(() => payment = v ?? 'نقدی')),
              const SizedBox(height: 12),
              const Text('مبلغ نهایی هنگام ثبت سفارش از قیمت اختصاصی مشتری محاسبه و در سفارش ذخیره می‌شود.'),
              if (error != null) Padding(padding: const EdgeInsets.all(8), child: Text(error!, style: const TextStyle(color: Colors.red))),
              const SizedBox(height: 8),
              FilledButton(onPressed: busy ? null : () => submit(customers), child: Text(busy ? 'در حال ثبت...' : 'ثبت سفارش')),
            ]);
          },
        );
      },
    ),
  );
}
